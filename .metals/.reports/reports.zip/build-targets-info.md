### Build targets for folder: 0
#### 0
java: ✅ 
interactive: ✅ 
debugging: ✅ 
diagnostics: ✅ 
compilationStatus: ✅ 
targetType: Scala 2.13.12
recommendation: Goto definition for Java classes will not work, please install jdk sources in java home. Searched: /usr/lib/jvm/src.zip, /usr/lib/jvm/lib/src.zip, /usr/lib/jvm/java-11-openjdk-amd64/src.zip, /usr/lib/jvm/java-11-openjdk-amd64/lib/src.zip, /usr/lib/jvm/src.zip, /usr/lib/jvm/lib/src.zip, /usr/lib/jvm/java-11-openjdk-amd64/src.zip, /usr/lib/jvm/java-11-openjdk-amd64/lib/src.zip
semanticdb: ✅ 

#### 1
java: ✅ 
interactive: ✅ 
debugging: ✅ 
diagnostics: ✅ 
compilationStatus: ✅ 
targetType: Scala 2.13.12
recommendation: Goto definition for Java classes will not work, please install jdk sources in java home. Searched: /usr/lib/jvm/src.zip, /usr/lib/jvm/lib/src.zip, /usr/lib/jvm/java-11-openjdk-amd64/src.zip, /usr/lib/jvm/java-11-openjdk-amd64/lib/src.zip, /usr/lib/jvm/src.zip, /usr/lib/jvm/lib/src.zip, /usr/lib/jvm/java-11-openjdk-amd64/src.zip, /usr/lib/jvm/java-11-openjdk-amd64/lib/src.zip
semanticdb: ✅ 

